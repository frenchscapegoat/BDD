DELETE FROM spectateur;
DELETE FROM tarif;
DELETE FROM evenement;
DELETE FROM acheteur;
